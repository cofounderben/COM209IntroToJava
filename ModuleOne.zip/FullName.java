//Written by Benjamin Smith
//July 5, 2015
//Chapter 1, Exercise 5
//Display full name on the screen

public class FullName
{
   public static void main(String[] args)
   {
      System.out.println("Benjamin Smith");
   }
}