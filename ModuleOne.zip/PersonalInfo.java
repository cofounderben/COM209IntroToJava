//Written by Benjamin Smith
//July 5, 2015
//Chapter 1, Exercise 6
//Display full name, email address, and phone number on three lines on the screen

public class PersonalInfo
{
   public static void main(String[] args)
   {
      System.out.println("Benjamin Smith");
      System.out.println("benjamin.smith06@email.saintleo.edu");
      System.out.println("616-430-2609");
   }
}